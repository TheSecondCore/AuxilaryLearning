class Node {
  constructor(data, next = null) {
    this.data = data;
    this.next = next;
  }
}

export default Node;
